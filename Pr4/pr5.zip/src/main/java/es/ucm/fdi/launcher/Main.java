package es.ucm.fdi.launcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;

import javax.swing.SwingUtilities;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import es.ucm.fdi.control.Controller;
import es.ucm.fdi.exceptions.SimulationException;
import es.ucm.fdi.ini.Ini;
import es.ucm.fdi.ini.IniSection;
import es.ucm.fdi.model.TrafficSimulator;
import es.ucm.fdi.model.event.Event;
import es.ucm.fdi.view.MainWindow;

public class Main {

	private final static Integer _timeLimitDefaultValue = 10;
	private static Integer _timeLimit = null;
	private static String _inFile = null;
	private static String _outFile = null;
	private static boolean _GUI = false;

	private static void parseArgs(String[] args) {

		// define the valid command line options
		//
		Options cmdLineOptions = buildOptions();

		// parse the command line as provided in args
		//
		CommandLineParser parser = new DefaultParser();
		try {
			CommandLine line = parser.parse(cmdLineOptions, args);
			parseHelpOption(line, cmdLineOptions);
			parseModeOption(line);
			parseInFileOption(line);
			parseOutFileOption(line);
			parseStepsOption(line);

			// if there are some remaining arguments, then something wrong is
			// provided in the command line!
			//
			String[] remaining = line.getArgs();
			if (remaining.length > 0) {
				String error = "Illegal arguments:";
				for (String o : remaining)
					error += (" " + o);
				throw new ParseException(error);
			}

		} catch (ParseException e) {
			// new Piece(...) might throw GameError exception
			System.err.println(e.getLocalizedMessage());
			System.exit(1);
		}

	}

	private static Options buildOptions() {
		Options cmdLineOptions = new Options();

		cmdLineOptions.addOption(Option.builder("h").longOpt("help")
				.desc("Print this message").build());
		cmdLineOptions.addOption(Option.builder("i").longOpt("input").hasArg()
				.desc("Events input file").build());
		cmdLineOptions.addOption(Option.builder("m").longOpt("mode").hasArg()
				.desc("'batch' for batch mode and 'gui' for GUI mode (default value is 'batch'")
				.build());
		cmdLineOptions.addOption(Option.builder("o").longOpt("output").hasArg()
				.desc("Output file, where reports are written.").build());
		cmdLineOptions.addOption(Option.builder("t").longOpt("ticks").hasArg()
				.desc("Ticks to execute the simulator's main loop (default value is "
						+ _timeLimitDefaultValue + ").")
				.build());

		return cmdLineOptions;
	}

	private static void parseHelpOption(CommandLine line,
			Options cmdLineOptions) {
		if ("batch".equals(line.getOptionValue("m")) && line.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp(Main.class.getCanonicalName(), cmdLineOptions,
					true);
			System.exit(0);
		}
	}

	private static void parseInFileOption(CommandLine line)
			throws ParseException {
		_inFile = line.getOptionValue("i");
		if (_inFile == null) {
			throw new ParseException("An events file is missing");
		}
	}

	private static void parseModeOption(CommandLine line)
			throws ParseException {
		if ("gui".equals(line.getOptionValue("m")))
			_GUI = true;
	}

	private static void parseOutFileOption(CommandLine line)
			throws ParseException {
		_outFile = line.getOptionValue("o");
	}

	private static void parseStepsOption(CommandLine line)
			throws ParseException {
		String t = line.getOptionValue("t", _timeLimitDefaultValue.toString());
		try {
			_timeLimit = Integer.parseInt(t);
			assert (_timeLimit < 0);
		} catch (Exception e) {
			throw new ParseException("Invalid value for time limit: " + t);
		}
	}

	/**
	 * This method run the simulator on all files that ends with .ini if the given path, and compares
	 * that output to the expected output. It assumes that for example "example.ini" the expected output
	 * is stored in "example.ini.eout". The simulator's output will be stored in "example.ini.out"
	 * 
	 * @throws IOException
	 */
	static boolean test(String path) throws IOException, SimulationException {

		File dir = new File(path);

		if (!dir.exists()) {
			throw new FileNotFoundException(path);
		}

		File[] files = dir.listFiles(new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				return name.endsWith(".ini");
			}
		});

		boolean result = true;
		for (File file : files) {
			result = result && test(file.getAbsolutePath(),
					file.getAbsolutePath() + ".out",
					file.getAbsolutePath() + ".eout", 10);
		}

		return result;
	}

	private static boolean test(String inFile, String outFile,
			String expectedOutFile, int timeLimit) throws IOException {
		_outFile = outFile;
		_inFile = inFile;
		_timeLimit = timeLimit;
		startBatchMode();
		boolean equalOutput = (new Ini(_outFile))
				.equals(new Ini(expectedOutFile));
		System.out.println("Result for: '" + _inFile + "' : " + (equalOutput
				? "OK!"
				: ("not equal to expected output +'" + expectedOutFile + "'")));
		return equalOutput;
	}

	/**
	 * Run the simulator in batch mode
	 * 
	 * @throws IOException
	 */
	private static void startBatchMode() throws IOException {
		// Add your code here. Note that the input argument where parsed and stored into
		// corresponding fields.

		// Leemos el fichero .ini
		File file = new File(_inFile);
		InputStream s = new FileInputStream(file);
		Ini ini = new Ini(s);

		// Insertamos todos los eventos
		TrafficSimulator tf = new TrafficSimulator();
		Controller controller = new Controller(tf);
		controller.insertarEventos(ini);

		// Añadimos un listener para mostrar errores
		controller.addSimulatorListener(new BatchErrorListener());

		controller.ejecuta(_timeLimit, new FileOutputStream(_outFile));
	}

	private static void startGUIMode() throws IOException {
		TrafficSimulator tf = new TrafficSimulator();
		Controller controller = new Controller(tf);

		SwingUtilities.invokeLater(
				() -> new MainWindow(controller, _inFile, _timeLimit));
	}

	private static void start(String[] args) throws IOException {
		parseArgs(args);
		if (_GUI) {
			startGUIMode();
		} else {
			startBatchMode();
		}
	}

	public static void main(String[] args) throws IOException,
			InvocationTargetException, InterruptedException {

		// example command lines:
		//
		// -i resources/examples/events/basic/ex1.ini
		// -i resources/examples/events/basic/ex1.ini -o ex1.out
		// -i resources/examples/events/basic/ex1.ini -t 20
		// -i resources/examples/events/basic/ex1.ini -o ex1.out -t 20
		// --help
		//

		// Call test in order to test the simulator on all examples in a directory.
		//
		// test("resources/examples/events/basic");

		// Call start to start the simulator from command line, etc.
		// test("/Users/Daniel/git/Pr4Local/Pr4/src/main/resources/examples/basic");
		start(args);
	}

}
