package es.ucm.fdi.extra.graphlayout;

public class Node {
	private String _id;

	public Node(String id) {
		_id = id;
	}

	public String getId() {
		return _id;
	}
}
